class Utils {
    constructor(debugging) {
        this.moduleName = 'chat-images';
        this._debugging = debugging;
        // CONFIG.debug.hooks = debugging;
        this.debugMode = debugging;
    }
    _log(output) {
        console.log(`%cChat Images %c|`, 'background: #222; color: #bada55', 'color: #fff', output);
    }
    debug(output) {
        if (this._debugging && output) {
            this._log(output);
        }
    }
}
export default new Utils(true);
