import utils from "./utils.js";
const settingsList = [
    {
        key: "warningOnDrop",
        settings: {
            name: "Enable warning on drop:",
            hint: "Enables a warning dialog when dropping an image in the chat.",
            type: Boolean,
            default: false,
            scope: "world",
            config: true,
        },
    },
    {
        key: "warningOnPaste",
        settings: {
            name: "Enable warning on paste:",
            hint: "Enables a warning dialog when pasting an image in the chat.",
            type: Boolean,
            default: false,
            scope: "world",
            config: true,
        },
    },
];
export const registerSettings = () => {
    settingsList.forEach((setting) => {
        game.settings.register(utils.moduleName, setting.key, setting.settings);
    });
};
