import ImageHandler from "../ImageHandler.js";
import Utils from "../Utils.js";
import Settings from "../Settings.js";
class RenderSidebarTab {
    constructor() {
    }
    static getInstance() {
        if (!RenderSidebarTab._instance)
            RenderSidebarTab._instance = new RenderSidebarTab();
        return RenderSidebarTab._instance;
    }
    /**
     * This function shows a spinner over the chat
     *
     * @param chat - chat html element
     * @param enable - true if the spinner needs to be displayed
     * @private
     */
    _toggleSpinner(chat, enable) {
        const chatForm = chat.parentNode;
        let spinner = document.querySelector(`#${Utils.moduleName}-spinner`);
        if (enable) {
            if (!spinner) {
                spinner = document.createElement('DIV');
                spinner.id = `${Utils.moduleName}-spinner`;
                chatForm.prepend(spinner);
            }
        }
        else {
            if (spinner)
                chatForm.removeChild(spinner);
        }
    }
    /**
     * This function adds the disabled property on the chat input
     *
     * @param chat - chat html object (should be the default textarea)
     * @param disabled - true, if the chat needs to be disabled
     * @private
     */
    _toggleChat(chat, disabled) {
        this._toggleSpinner(chat, disabled);
        if (disabled) {
            chat.setAttribute('disabled', 'true');
        }
        else {
            chat.removeAttribute('disabled');
            chat.focus();
        }
    }
    /**
     * Showing images as blobs in the chat for people who don't trust their players
     *
     * @param chat - chat html element
     * @param imageBlob - image blob
     * @private
     */
    _createChatMessageWithBlobImage(chat, imageBlob) {
        const renderSidebarTabInstance = this;
        this._toggleChat(chat, true);
        const reader = new FileReader();
        reader.onload = (event) => {
            const content = ImageHandler.buildImageHtml(event.target.result, true);
            ChatMessage.create({ content }).then(() => {
                renderSidebarTabInstance._toggleChat(chat, false);
            });
        };
        reader.readAsDataURL(imageBlob);
    }
    /**
     * Create a new chat message with a image file path from the data directory
     *
     * @param chat - chat html element
     * @param image - image file
     * @private
     */
    _createChatMessageWithFilePath(chat, image) {
        const renderSidebarTabInstance = this;
        const uploadFolderPath = Settings.getUploadFolderPath();
        const imageName = ImageHandler.generateRandomFileName(image.name);
        const imageToUpload = new File([image], imageName, { type: image.type });
        FilePicker.upload('data', uploadFolderPath, imageToUpload, {}).then(() => {
            const content = ImageHandler.buildImageHtml(`./${uploadFolderPath}/${imageName}`, false);
            ChatMessage.create({ content }).then(() => {
                renderSidebarTabInstance._toggleChat(chat, false);
            });
        });
    }
    /**
     * Create a new chat message with the pasted/dropped image
     *
     * @param chat - chat html element
     * @param imageBlob - image blob
     * @private
     */
    _sendMessageInChat(chat, imageBlob) {
        if (!imageBlob)
            return;
        const whereToSave = Settings.getSetting('whereToSavePastedImages');
        if (whereToSave === 'dataFolder') {
            this._createChatMessageWithFilePath(chat, imageBlob);
        }
        else {
            this._createChatMessageWithBlobImage(chat, imageBlob);
        }
    }
    /**
     * Build a warning dialog
     *
     * @param chat - chat html object (should be the default textarea)
     * @param imageBlob - image blob
     * @private
     */
    _createWarningDialog(chat, imageBlob) {
        const renderSidebarTabInstance = this;
        let tookAction = false;
        this._toggleChat(chat, true);
        return new Dialog({
            title: 'Warning',
            content: 'You\'re about to send a file, are you sure?',
            buttons: {
                ok: {
                    icon: '<i class="fas fa-check"></i>',
                    label: 'Yes',
                    callback: () => {
                        tookAction = true;
                        renderSidebarTabInstance._sendMessageInChat(chat, imageBlob);
                    }
                },
                cancel: {
                    icon: '<i class="fas fa-times"></i>',
                    label: 'No',
                    callback: () => {
                        tookAction = true;
                        renderSidebarTabInstance._toggleChat(chat, false);
                    }
                }
            },
            default: 'ok',
            close: () => {
                if (!tookAction) {
                    renderSidebarTabInstance._toggleChat(chat, false);
                }
            }
        });
    }
    /**
     * Show a warning if needed and send the message
     *
     * @param warning - true, if we need to show a warning
     * @param chat - chat html object (should be the default textarea)
     * @param imageBlob - image blob
     * @private
     */
    _warnAndSendMessage(warning, chat, imageBlob) {
        if (!chat || !imageBlob)
            return;
        if (warning) {
            this._createWarningDialog(chat, imageBlob).render(true);
        }
        else {
            this._sendMessageInChat(chat, imageBlob);
        }
    }
    /**
     * Event handler for the paste event
     *
     * @param event - paste event
     * @private
     */
    _pasteEventListener(event) {
        const chat = event.target;
        if (!chat || chat.disabled)
            return;
        const hasWarningOnPaste = Settings.getSetting('warningOnPaste');
        this._warnAndSendMessage(hasWarningOnPaste, chat, ImageHandler.getBlobFromEvents(event));
    }
    /**
     * Event handler for the drop event
     *
     * @param event - drop event
     * @private
     */
    _dropEventListener(event) {
        const chat = event.target;
        if (!chat || chat.disabled)
            return;
        const hasWarningOnDrop = Settings.getSetting('warningOnDrop');
        this._warnAndSendMessage(hasWarningOnDrop, chat, ImageHandler.getBlobFromEvents(event));
    }
    /**
     * Add event listeners for the chat textarea
     *
     * @param chat - chat html object (should be the default textarea)
     * @private
     */
    _addChatEventListeners(chat) {
        chat.addEventListener('paste', this._pasteEventListener.bind(this));
        chat.addEventListener('drop', this._dropEventListener.bind(this));
    }
    /**
     * Add a hook on renderSidebarTab, to add the paste/drop events on the chat window
     *
     * @param _0 - side panel object, ignored
     * @param sidePanel - side panel html
     * @public
     */
    renderSidebarTabHook(_0, sidePanel) {
        const sidePanelHTML = sidePanel[0];
        if (sidePanelHTML?.id !== 'chat')
            return;
        const chat = sidePanelHTML.querySelector('#chat-message');
        if (!chat)
            return;
        this._addChatEventListeners(chat);
    }
}
export default RenderSidebarTab.getInstance();
