import ImageHandler from "../ImageHandler.js";
class PreCreateChatMessage {
    /**
     * This function returns the chat message content with all the image links replaced with
     * actual images
     *
     * @param content - ChatMessage content
     */
    processMessage(content) {
        return ImageHandler.replaceImagesInText(content);
    }
}
export default new PreCreateChatMessage();
