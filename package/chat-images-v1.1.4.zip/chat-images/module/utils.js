class Utils {
    constructor(debugging, trace) {
        this.moduleName = 'chat-images';
        this._debugging = debugging;
        this._trace = trace;
        if (debugging)
            CONFIG.debug.hooks = debugging;
    }
    _consoleLog(output) {
        console.log(`%cChat Images %c|`, 'background: #222; color: #bada55', 'color: #fff', output);
    }
    _consoleTrace(output) {
        console.groupCollapsed(`%cChat Images %c|`, 'background: #222; color: #bada55', 'color: #fff', output);
        console.trace();
        console.groupEnd();
    }
    debug(output, doTrace) {
        if (this._debugging && output) {
            if (this._trace && doTrace !== false) {
                this._consoleTrace(output);
            }
            else {
                this._consoleLog(output);
            }
        }
    }
}
export default new Utils(true, true);
