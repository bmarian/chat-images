import ImageHandler from "../ImageHandler.js";
class PreCreateChatMessage {
    constructor() {
    }
    static getInstance() {
        if (!PreCreateChatMessage._instance)
            PreCreateChatMessage._instance = new PreCreateChatMessage();
        return PreCreateChatMessage._instance;
    }
    /**
     * This function returns the chat message content with all the image links replaced with
     * actual images
     *
     * @param content - ChatMessage content
     */
    _processMessage(content) {
        return ImageHandler.replaceImagesInText(content);
    }
    /**
     * Adding a hook on preCreateChatMessage to get the message before is posted in chat and to
     * manipulate the data
     */
    preCreateChatMessageHook(message, options) {
        if (!message?.content)
            return;
        const { content, changed } = this._processMessage(message.content);
        if (!changed)
            return;
        message.content = content;
        options.chatBubble = !changed;
    }
}
export default PreCreateChatMessage.getInstance();
