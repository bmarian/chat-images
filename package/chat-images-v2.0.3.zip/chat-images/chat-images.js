import PreCreateChatMessage from "./module/hooks/PreCreateChatMessage.js";
import RenderSidebarTab from "./module/hooks/RenderSidebarTab.js";
import RenderChatMessage from "./module/hooks/RenderChatMessage.js";
import Init from "./module/hooks/Init.js";
Hooks.once('init', Init.initHook.bind(Init));
Hooks.on('renderSidebarTab', RenderSidebarTab.renderSidebarTabHook.bind(RenderSidebarTab));
Hooks.on('preCreateChatMessage', PreCreateChatMessage.preCreateChatMessageHook.bind(PreCreateChatMessage));
Hooks.on('renderChatMessage', RenderChatMessage.RenderChatMessageHook.bind(RenderChatMessage));
