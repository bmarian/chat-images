import Settings from "../Settings.js";
class Init {
    constructor() {
    }
    static getInstance() {
        if (!Init._instance)
            Init._instance = new Init();
        return Init._instance;
    }
    /**
     * Add a hook on init, to register settings, and to create the Upload folder if it doesn't exist
     */
    async initHook() {
        Settings.registerSettings();
        Settings.createChatImageFolderIfMissing();
    }
}
export default Init.getInstance();
