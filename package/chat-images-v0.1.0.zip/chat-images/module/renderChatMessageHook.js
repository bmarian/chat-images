class RenderChatMessageHook {
    _togglePreviewButton(previewButton, disabled) {
        if (disabled) {
            previewButton.setAttribute('disabled', 'true');
        }
        else {
            previewButton.removeAttribute('disabled');
        }
    }
    _imagePopoutTemplate(image, previewButton) {
        const that = this;
        const container = document.createElement('DIV');
        const img = document.createElement('img');
        container.className = 'chat-images-dialog-preview';
        img.className = 'chat-images-dialog-image';
        img.src = image;
        img.alt = 'image';
        container.appendChild(img);
        container.addEventListener('click', event => {
            that._togglePreviewButton(previewButton, false);
            container === null || container === void 0 ? void 0 : container.parentNode.removeChild(container);
        });
        return container;
    }
    _buttonClickEventListener(button, container) {
        const image = container.querySelector('.chat-images-image');
        const previewButton = container.querySelector('.chat-images-expand-preview-button');
        if (!image || !previewButton) {
            return;
        }
        this._togglePreviewButton(previewButton, true);
        const popout = this._imagePopoutTemplate(image.src, previewButton);
        document.body.prepend(popout);
    }
    addImagePreviewButton(_0, html, _1) {
        if (!(html && html[0])) {
            return;
        }
        const container = html[0].querySelector('.chat-images-image-container');
        if (container) {
            const that = this;
            const buttons = container.querySelectorAll('.chat-images-expand-preview-button');
            buttons.forEach(button => {
                button.addEventListener('click', () => {
                    that._buttonClickEventListener(this, container);
                });
            });
        }
    }
}
export default new RenderChatMessageHook();
