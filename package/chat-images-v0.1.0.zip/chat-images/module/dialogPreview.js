import utils from "./utils.js";
class DialogPreview {
    constructor(image) {
        this._image = image;
    }
    _buttonClickEventListener() {
        utils.debug('Expand button clicked');
    }
    generateButton() {
        const button = document.createElement('BUTTON');
        button.className = 'chat-images-expand-preview-button';
        button.innerHTML = '<i class="fas fa-expand" aria-hidden="true"></i>';
        button.addEventListener('click', this._buttonClickEventListener.bind(this));
        return button;
    }
}
export default DialogPreview;
