import utils from "./utils.js";
class PreCreateChatMessageHook {
    constructor() {
        this._urlRegex = /<a class="hyperlink" href=".*" target=".*">(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])<\/a>|(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    }
    _isImageURL(link) {
        return !!link.match(/\w+\.(jpg|jpeg|gif|png|tiff|bmp)/gi);
    }
    _buildImage(imgLink) {
        return `<div class="chat-images-image-container">
                    <button class="chat-images-expand-preview-button">
                        <i class="fas fa-expand" aria-hidden="true"></i>
                    </button>
                    <a class="hyperlink" href="${imgLink}" target="_blank">
                        <img class="chat-images-image" src="${imgLink}" alt="${imgLink}">        
                    </a>
                </div>`;
    }
    _parseMessage(match, link) {
        if (this._isImageURL(link ? link : match)) {
            return link ? this._buildImage(link) : this._buildImage(match);
        }
        else {
            return match;
        }
    }
    processMessage(content) {
        const parsedContent = content.replace(this._urlRegex, this._parseMessage.bind(this));
        utils.debug(parsedContent);
        return parsedContent;
    }
}
export default new PreCreateChatMessageHook();
