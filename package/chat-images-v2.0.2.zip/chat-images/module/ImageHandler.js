import utils from "./Utils.js";
class ImageHandler {
    constructor() {
        this.urlRegex = /^<a.*>(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])<\/a>$/ig;
        this.imageUrlRegex = /\w+\.(jpg|jpeg|gif|png|tiff|bmp)/gi;
    }
    static getInstance() {
        if (!ImageHandler._instance)
            ImageHandler._instance = new ImageHandler();
        return ImageHandler._instance;
    }
    /**
     * This function checks if an url is for an image
     *
     * @param link - url of the image
     * @private
     */
    _isImageUrl(link) {
        return !!link.match(this.imageUrlRegex);
    }
    /**
     * This function creates the HTML structure that will be shown in the chat
     *
     * @param image - (url/base64)
     * @param isBase64 - determines if an image is an url of a base64 string
     * @private
     */
    buildImageHtml(image, isBase64) {
        const img = `<img class="${utils.moduleName}-image" src="${image}" alt="${utils.moduleName}">`;
        return `<div class="${utils.moduleName}-image-container">${img}</div>`;
    }
    /**
     * This function converts all the image links into actual images
     *
     * @param match
     * @param link
     * @private
     */
    _changeLinksToImages(match, link) {
        return this._isImageUrl(link) ? this.buildImageHtml(link, false) : match;
    }
    /**
     * This function receives a string and converts all the image links into actual images
     *
     * @param message - text containing image links to change
     */
    replaceImagesInText(message) {
        if (!message)
            return;
        return {
            content: message.replace(this.urlRegex, this._changeLinksToImages.bind(this)),
            changed: !!message.match(this.urlRegex)
        };
    }
    /**
     * This function extracts the image from a paste event or from a drop event.
     *
     * @param event - paste/drop event
     */
    getBlobFromEvents(event) {
        const items = event?.clipboardData?.items || event?.dataTransfer?.items;
        let blob = null;
        for (let i = 0; i < items.length; i++) {
            if (items[i]?.type.includes('image')) {
                blob = items[i].getAsFile();
                break;
            }
        }
        return blob;
    }
    /**
     * Generate a random file name for images
     *
     * @param oldImageName - the original file name (used to get the extension for the file)
     */
    generateRandomFileName(oldImageName) {
        const imageExtension = oldImageName.substring(oldImageName.lastIndexOf('.'), oldImageName.length) || null;
        if (!imageExtension)
            return oldImageName;
        const randomName = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        return randomName + imageExtension;
    }
}
export default ImageHandler.getInstance();
