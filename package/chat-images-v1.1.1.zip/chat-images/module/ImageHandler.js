import utils from "./utils.js";
class ImageHandler {
    constructor() {
        this.urlRegex = /<a.*>(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])<\/a>|(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
        this.imageUrlRegex = /\w+\.(jpg|jpeg|gif|png|tiff|bmp)/gi;
    }
    /**
     * This function checks if an url is for an image
     *
     * @param link - url of the image
     * @private
     */
    _isImageUrl(link) {
        return !!link.match(this.imageUrlRegex);
    }
    /**
     * This function creates the HTML structure that will be shown in the chat
     *
     * @param image - (url/base64)
     * @param isBase64 - determines if an image is an url of a base64 string
     * @private
     */
    buildImageHtml(image, isBase64) {
        const img = `<img class="${utils.moduleName}-image" src="${image}" alt="${utils.moduleName}">`;
        const link = isBase64 ? img : `<a class="hyperlink" href="${image}" target="_blank">${img}</a>`;
        const previewButton = `<button class="${utils.moduleName}-expand-preview-button">
                                    <i class="fas fa-expand" aria-hidden="true"></i>
                               </button>`;
        return `<div class="${utils.moduleName}-image-container">${previewButton}${link}</div>`;
    }
    /**
     * This function converts all the image links into actual images
     *
     * @param match
     * @param link - it only exists if the original link is detected and converted into a hyperlink
     * @private
     */
    _changeLinksToImages(match, link) {
        const image = link ? link : match;
        return this._isImageUrl(image) ? this.buildImageHtml(image, false) : match;
    }
    /**
     * This function receives a string and converts all the image links into actual images
     *
     * @param message - text containing image links to change
     */
    replaceImagesInText(message) {
        if (!message)
            return;
        return {
            content: message.replace(this.urlRegex, this._changeLinksToImages.bind(this)),
            changed: !!message.match(this.urlRegex)
        };
    }
    /**
     * This function extracts the image from a paste event or from a drop event.
     *
     * @param event - paste/drop event
     */
    getBlobFromFile(event) {
        var _a, _b, _c;
        const items = ((_a = event === null || event === void 0 ? void 0 : event.clipboardData) === null || _a === void 0 ? void 0 : _a.items) || ((_b = event === null || event === void 0 ? void 0 : event.dataTransfer) === null || _b === void 0 ? void 0 : _b.items);
        let blob = null;
        for (let i = 0; i < items.length; i++) {
            if ((_c = items[i]) === null || _c === void 0 ? void 0 : _c.type.includes('image')) {
                blob = items[i].getAsFile();
                break;
            }
        }
        return blob;
    }
}
export default new ImageHandler();
