class RenderSidebarTabHook {
    _generateMessage(image) {
        return `<div class="chat-images-image-container">
                    <button class="chat-images-expand-preview-button">
                        <i class="fas fa-expand" aria-hidden="true"></i>
                    </button>
                    <img class="chat-images-image" src="${image}" alt="image">
                </div>`;
    }
    _toggleSpinner(chat, enable) {
        const chatForm = chat.parentNode;
        if (enable) {
            const spinner = document.createElement('DIV');
            spinner.id = 'chat-image-spinner';
            chatForm.prepend(spinner);
        }
        else {
            const spinner = document.querySelector('#chat-image-spinner');
            chatForm.removeChild(spinner);
        }
    }
    _toggleChat(chat, disabled) {
        this._toggleSpinner(chat, disabled);
        if (disabled) {
            chat.setAttribute('disabled', 'true');
        }
        else {
            chat.removeAttribute('disabled');
            chat.focus();
        }
    }
    _parseImage(chat, event) {
        var _a, _b, _c;
        const items = ((_a = event === null || event === void 0 ? void 0 : event.clipboardData) === null || _a === void 0 ? void 0 : _a.items) || ((_b = event === null || event === void 0 ? void 0 : event.dataTransfer) === null || _b === void 0 ? void 0 : _b.items);
        let blob = null;
        for (let i = 0; i < items.length; i++) {
            if ((_c = items[i]) === null || _c === void 0 ? void 0 : _c.type.includes('image')) {
                blob = items[i].getAsFile();
                break;
            }
        }
        return blob;
    }
    _sendMessageInChat(chat, image) {
        const reader = new FileReader();
        const that = this;
        if (image !== null) {
            this._toggleChat(chat, true);
            reader.onload = event => {
                const chatData = {
                    content: that._generateMessage(event.target.result),
                };
                ChatMessage.create(chatData).then(() => {
                    that._toggleChat(chat, false);
                });
            };
            reader.readAsDataURL(image);
        }
    }
    _pasteEventListener(event) {
        const chat = event.target;
        if (chat.disabled) {
            return;
        }
        const blob = this._parseImage(chat, event);
        this._sendMessageInChat(chat, blob);
    }
    handleImagePaste(chat) {
        chat.addEventListener('paste', this._pasteEventListener.bind(this));
        chat.addEventListener('drop', this._pasteEventListener.bind(this));
    }
}
export default new RenderSidebarTabHook();
