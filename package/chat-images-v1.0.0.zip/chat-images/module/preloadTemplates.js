export const preloadTemplates = async function () {
    const templatePaths = [];
    return loadTemplates(templatePaths);
};
